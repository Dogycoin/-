<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="setup_tile" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="../../graphics/enemy/setup_tile.png" width="128" height="64"/>
</tileset>
